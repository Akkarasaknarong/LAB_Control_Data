# FRA233_Lab1_System_Identification

## Step 1
If you don't have Git in your PC, download it [here](https://git-scm.com/install/)

## Step 2: Clone Repository
```bash
git clone https://github.com/pboon09/FRA233_Lab1_System_Identification.git
```